from pathlib import Path
import shutil, sys, xml.etree.ElementTree as ET
from PIL import Image
root=Path(sys.argv[1]); source=Path(__file__).parent
app=root/'android/app/src/main'; res=app/'res'; kotlin=app/'kotlin/com/yurtmenu/yurtmenu'; kotlin.mkdir(parents=True,exist_ok=True)
for f in (source/'kotlin').glob('*.kt'): shutil.copy(f,kotlin/f.name)
shutil.copytree(source/'res',res,dirs_exist_ok=True)
im=Image.open(source/'icon.png').convert('RGB')
for name,sz in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
 d=res/f'mipmap-{name}';d.mkdir(exist_ok=True);im.resize((sz,sz),Image.Resampling.LANCZOS).save(d/'ic_launcher.png')
d=res/'drawable-nodpi';d.mkdir(exist_ok=True);im.resize((192,192),Image.Resampling.LANCZOS).save(d/'splash_logo.png')
# pre Android 12 background, logo centered at intrinsic drawable size
for folder in ['drawable','drawable-v21']:
 d=res/folder;d.mkdir(exist_ok=True);(d/'launch_background.xml').write_text('<layer-list xmlns:android="http://schemas.android.com/apk/res/android"><item android:drawable="@color/launch_bg"/><item><bitmap android:gravity="center" android:src="@drawable/splash_logo"/></item></layer-list>')
(res/'values'/'launch_colors.xml').write_text('<resources><color name="launch_bg">#100E0E</color></resources>')
for folder in ['values-v31','values-night-v31']:
 d=res/folder;d.mkdir(exist_ok=True);(d/'styles.xml').write_text('''<resources><style name="LaunchTheme" parent="@android:style/Theme.Material.NoActionBar"><item name="android:windowSplashScreenBackground">@color/launch_bg</item><item name="android:windowSplashScreenAnimatedIcon">@drawable/splash_logo</item><item name="android:windowBackground">@drawable/launch_background</item></style><style name="NormalTheme" parent="@android:style/Theme.Material.NoActionBar"><item name="android:windowBackground">@color/launch_bg</item></style></resources>''')
ns='http://schemas.android.com/apk/res/android';ET.register_namespace('android',ns);a='{'+ns+'}';f=app/'AndroidManifest.xml';tree=ET.parse(f);m=tree.getroot();application=m.find('application');application.set(a+'label','YurtMenü')
for perm in ['INTERNET','POST_NOTIFICATIONS','RECEIVE_BOOT_COMPLETED']:
 if not any(e.get(a+'name')=='android.permission.'+perm for e in m.findall('uses-permission')): m.insert(0,ET.Element('uses-permission',{a+'name':'android.permission.'+perm}))
receiver=ET.SubElement(application,'receiver',{a+'name':'.MenuWidget',a+'exported':'true',a+'label':'YurtMenü · Günlük menü'});fil=ET.SubElement(receiver,'intent-filter');ET.SubElement(fil,'action',{a+'name':'android.appwidget.action.APPWIDGET_UPDATE'});ET.SubElement(receiver,'meta-data',{a+'name':'android.appwidget.provider',a+'resource':'@xml/menu_widget_info'})
ET.SubElement(application,'receiver',{a+'name':'.MealReceiver',a+'exported':'false'})
receiver=ET.SubElement(application,'receiver',{a+'name':'.BootReceiver',a+'exported':'false'});fil=ET.SubElement(receiver,'intent-filter')
for action in ['BOOT_COMPLETED','MY_PACKAGE_REPLACED','TIME_SET','TIMEZONE_CHANGED']: ET.SubElement(fil,'action',{a+'name':'android.intent.action.'+action})
tree.write(f,encoding='utf-8',xml_declaration=True)
