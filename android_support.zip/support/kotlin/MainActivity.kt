package com.yurtmenu.yurtmenu

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var permissionResult: MethodChannel.Result? = null
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.yurtmenu/native").setMethodCallHandler { call, result ->
            when(call.method) {
                "sync" -> {
                    val p = MenuNative.prefs(this).edit()
                    for (key in listOf("menus", "favorites")) p.putString(key, call.argument<String>(key) ?: "")
                    for (key in listOf("morningAlert", "eveningAlert", "favoriteAlert")) p.putBoolean(key, call.argument<Boolean>(key) ?: false)
                    for (key in listOf("morningMinutes", "eveningMinutes")) p.putInt(key, call.argument<Int>(key) ?: if(key == "morningMinutes") 480 else 1020)
                    p.apply()
                    MenuNative.updateWidgets(this)
                    MenuNative.schedule(this)
                    result.success(null)
                }
                "permission" -> {
                    if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) result.success(true)
                    else if (permissionResult != null) result.success(false)
                    else { permissionResult = result; requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 204) }
                }
                "open" -> {
                    try { val uri = Uri.parse(call.arguments as String); require(uri.scheme == "https"); startActivity(Intent(Intent.ACTION_VIEW, uri)); result.success(null) }
                    catch(e: Exception) { result.error("OPEN", "Bağlantı açılamadı", null) }
                }
                else -> result.notImplemented()
            }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == 204) { permissionResult?.success(grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED); permissionResult = null }
    }
}
