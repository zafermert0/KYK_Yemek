package com.yurtmenu.yurtmenu

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONObject
import org.json.JSONArray
import java.util.Calendar
import java.util.TimeZone
import java.util.Locale
import java.text.SimpleDateFormat

object MenuNative {
    private val zone = TimeZone.getTimeZone("Europe/Istanbul")
    private val locale = Locale("tr", "TR")
    fun prefs(c: Context) = c.getSharedPreferences("menu_native", Context.MODE_PRIVATE)
    private fun date(pattern: String): String = SimpleDateFormat(pattern, locale).apply { timeZone = zone }.format(java.util.Date())
    fun items(c: Context, morning: Boolean): List<String> = try {
        val a = JSONObject(prefs(c).getString("menus", "{}") ?: "{}").optJSONObject(date("yyyy-MM-dd"))?.optJSONArray(if(morning) "breakfast" else "dinner") ?: JSONArray()
        (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    } catch(e: Exception) { emptyList() }
    private fun launch(c: Context): PendingIntent = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun updateWidgets(c: Context) {
        val manager = AppWidgetManager.getInstance(c)
        val ids = manager.getAppWidgetIds(ComponentName(c, MenuWidget::class.java))
        val morning = Calendar.getInstance(zone).get(Calendar.HOUR_OF_DAY) < 12
        val views = RemoteViews(c.packageName, R.layout.menu_widget)
        views.setTextViewText(R.id.widget_title, "Ankara · ${if(morning) "Kahvaltı" else "Akşam Yemeği"}")
        views.setTextViewText(R.id.widget_date, date("d MMMM, EEEE") + " · Kayıtlı menü")
        views.setTextViewText(R.id.widget_meals, items(c,morning).joinToString("\n") { "• $it" }.ifBlank { "Bu öğün için kayıt yok." })
        views.setOnClickPendingIntent(R.id.widget_root, launch(c))
        if(ids.isNotEmpty()) manager.updateAppWidget(ids, views)
    }
    private fun alarm(c: Context, morning: Boolean): PendingIntent = PendingIntent.getBroadcast(c, if(morning) 21 else 22, Intent(c, MealReceiver::class.java).putExtra("morning", morning), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun schedule(c: Context) {
        val p = prefs(c); val manager = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for(morning in listOf(true,false)) {
            val pi = alarm(c,morning); manager.cancel(pi)
            if(!p.getBoolean(if(morning) "morningAlert" else "eveningAlert",false) && !p.getBoolean("favoriteAlert",false)) continue
            val minutes = p.getInt(if(morning) "morningMinutes" else "eveningMinutes", if(morning) 480 else 1020).coerceIn(0,1439)
            val next = Calendar.getInstance(zone).apply { set(Calendar.HOUR_OF_DAY, minutes/60); set(Calendar.MINUTE,minutes%60); set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.timeInMillis,pi)
        }
    }
    fun notifyMeal(c: Context, morning: Boolean) {
        val p = prefs(c); val dishes = items(c,morning)
        val favorites = try { val a = JSONArray(p.getString("favorites","[]")); (0 until a.length()).map { a.optString(it).lowercase(locale) }.filter { it.isNotBlank() } } catch(e:Exception) { emptyList() }
        val matches = if(p.getBoolean("favoriteAlert",false)) dishes.filter { d -> favorites.any { d.lowercase(locale).contains(it) } } else emptyList()
        val enabled = p.getBoolean(if(morning) "morningAlert" else "eveningAlert",false)
        if((!enabled && matches.isEmpty()) || dishes.isEmpty()) return
        val manager = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(!manager.areNotificationsEnabled()) return
        val meal = if(morning) "Kahvaltı" else "Akşam yemeği"
        val channel = "daily_meals"
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channel,"Yemek bildirimleri",NotificationManager.IMPORTANCE_DEFAULT))
        val body = if(enabled) dishes.joinToString(" · ") else matches.joinToString(" · ")
        val builder = if(Build.VERSION.SDK_INT>=26) Notification.Builder(c,channel) else Notification.Builder(c)
        val notification = builder.setSmallIcon(R.drawable.ic_meal_notification).setContentTitle(if(matches.isEmpty()) meal else "Favori yemeğin menüde · $meal").setContentText(body).setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(launch(c)).setAutoCancel(true).build()
        try { manager.notify(if(morning) 101 else 102,notification) } catch(_: SecurityException) {}
    }
}
class MenuWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { MenuNative.updateWidgets(context) }
    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, options: android.os.Bundle) { MenuNative.updateWidgets(context) }
}
class MealReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { MenuNative.notifyMeal(context,intent.getBooleanExtra("morning",true)); MenuNative.schedule(context); MenuNative.updateWidgets(context) }
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { MenuNative.schedule(context); MenuNative.updateWidgets(context) }
}
